<?php

namespace App\Http\Controllers;

use App\Advertisement;
use Illuminate\Http\Request;

class AdvertisementController extends Controller
{
    public function index(){
        $lists = new Advertisement();
        $lists = Advertisement::all();

        return view('admin.ads-list')->with('lists',$lists);

    }

    public function ads_submit(Request $request){
        $ads = new Advertisement();
//        dd($request->all());
        $ads->title = $request->input('title');
        $ads->link = $request->input('link');
        $ads->images = $request->input('filepath');
        $ads->status = $request->input('status');
        $success = $ads->save();
        if ($success){
            return redirect()->route('ads_list')->with('status','Ads Created Succesfully');
        }else{
            return redirect()->route('ads_list')->with('error','Ads cant be created');
        }


    }
}

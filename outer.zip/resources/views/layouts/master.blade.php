@include('home.section.header')

    @yield('main-content')

<!--   ***********************nav bar ends***************** -->
<!--   ***********************main landing starts***************** -->

@include('home.section.footer')

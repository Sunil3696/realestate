@extends('layouts.admin-dashboard')
@section('title','Admin| File Manager')
@section('main-content')
    <iframe src="/laravel-filemanager" style="width: 100%; height: 500px; overflow: hidden; border: none;"></iframe>


@endsection

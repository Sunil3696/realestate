Hello! {{$email_data['name']}}
<br><br>
Welcome to Hbooking
<br>
Please click the link below to verify your account
<br><br>
<a href="http://merorealstate.loc/verify?code={{ $email_data['verification_code'] }}">Click Here</a>
<br><br>
ThankYOu
<br>

<?php $__env->startSection('title','Products || prithakrealstate'); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12 grid-margin">
            <div class="d-flex justify-content-between flex-wrap">
                <div class="d-flex align-items-end flex-wrap">
                    <div class="mr-md-3 mr-xl-5">
                        <h2>Product Details</h2>
                        <?php if(session('status')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                </div>
                <div class="d-flex justify-content-between align-items-end flex-wrap">
                    <a href="<?php echo e(route('product-add')); ?>" class="btn btn-primary mt-2 mt-xl-0">  <i class="mdi mdi-plus-circle"></i> Add Product</a>

                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12 stretch-card">
            <div class="card">
                <div class="card-body">

                    <div class="table-responsive">
                        <table id="recent-purchases-listing" class="table">
                            <thead>
                            <tr>
                                <th>SN</th>
                                <th>Title</th>
                                <th>Category</th>
                                <th>Price</th>
                                <th>Location</th>
                                <th>Image</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $product_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($info->id); ?></td>
                                    <td><?php echo e($info->title); ?></td>
                                    <td><?php echo e($info->category); ?></td>
                                    <td><?php echo e($info->price); ?></td>
                                    <td><?php echo e($info->location); ?></td>
                                    <td><img src="<?php echo e(asset($info->images)); ?>" style="width: 80px; height: 80px;"></td>
                                    <td><?php echo e($info->status); ?></td>
                                    <td><a href="<?php echo e(route('pedit',$info->id)); ?>">Edit</a>|| <a href="<?php echo e(route('destroy', $info->id)); ?>">Delete</a></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/merorealstate/resources/views/admin/product-list.blade.php ENDPATH**/ ?>
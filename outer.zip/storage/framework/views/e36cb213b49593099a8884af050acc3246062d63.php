<?php $__env->startSection('title','Rents || Mero real state'); ?>
<?php $__env->startSection('main-content'); ?>
    <style>
        .card {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            max-width: 300px;
            margin: auto;
            text-align: center;
            font-family: arial;
        }

        .price {
            color: grey;
            font-size: 22px;
        }

        .card button {
            border: none;
            outline: 0;
            padding: 12px;
            color: white;
            background-color: #000;
            text-align: center;
            cursor: pointer;
            width: 100%;
            font-size: 18px;
        }

        .card button:hover {
            opacity: 0.7;
        }
    </style>
    <div class="container" style="margin-left: 8px; >
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <div class="row" style="margin-left: 80px;">
                    <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4">









                        <div class="card">
                            <a href="<?php echo e(route('view_detail' , $rents->id)); ?>"> <img src="<?php echo e($rents->images); ?>" alt="Denim Jeans" style="height: 280px"></a>
                            <h4><?php echo e($rents->title); ?></h4>
                            <p class="price">Npr. <?php echo e($rents->price); ?></p>
                            <p style="height: 20px; overflow: hidden;"><?php echo e($rents->short_desc); ?></p>

                        </div><br><br>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div></div></div></div>

    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/merorealstate/resources/views/home/rent.blade.php ENDPATH**/ ?>
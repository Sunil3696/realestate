<?php $__env->startSection('title','Rents || Mero real state'); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="container" style="margin-left: 8px; >
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <div class="row" style="margin-left: 45px;">
                <?php if(isset($search)): ?>
                <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4">
                        <div class="card" style="border: none;">
                            <img src="<?php echo e($search->images); ?>" alt="" class="img-fluid">
                            <h6 class="pl-5 pt-3 font-weight-bold">NRS. <?php echo e($search->price); ?></h6>
                            <p class="px-3"> <?php echo e($search->short_desc); ?></p>

                            <a href="<?php echo e(route('view_detail' , $search->id)); ?>" class="btn btn-outline-success" style="margin-bottom: 80px;">Learn More</a>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>


            </div>

        </div>
    </div>
        <?php if($search = 0): ?>
            <h1>No Products Available On your Search</h1><a href="<?php echo e(route('property_for_sell')); ?>">Click here</a><label>To See Our products

        <?php endif; ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/merorealstate/resources/views/home/results.blade.php ENDPATH**/ ?>
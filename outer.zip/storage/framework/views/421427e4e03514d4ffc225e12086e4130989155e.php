Hello! <?php echo e($email_data['name']); ?>

<br><br>
Welcome to Hbooking
<br>
Please click the link below to verify your account
<br><br>
<a href="http://merorealstate.loc/verify?code=<?php echo e($email_data['verification_code']); ?>">Click Here</a>
<br><br>
ThankYOu
<br>
<?php /**PATH /var/www/html/merorealstate/resources/views/mail/signup-email.blade.php ENDPATH**/ ?>
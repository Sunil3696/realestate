<?php echo $__env->make('home.section.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('main-content'); ?>

<!--   ***********************nav bar ends***************** -->
<!--   ***********************main landing starts***************** -->

<?php echo $__env->make('home.section.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/merorealstate/resources/views/layouts/master.blade.php ENDPATH**/ ?>